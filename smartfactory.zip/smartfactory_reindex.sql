-- ====================================================================
-- SMARTFACTORY DATABASE RE-INDEXING & OPTIMIZATION SCRIPT
-- Role: Database Optimization Expert
-- Target: Replace "Fat Covering Index" with "Lean Index" to save Cloud Storage
-- ====================================================================

USE smartfactory_db;

-- 1. KIỂM TRA TRẠNG THÁI & DUNG LƯỢNG BAN ĐẦU
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT 
    table_name AS `Table`,
    ROUND(((data_length) / 1024 / 1024), 2) AS `Data Size (MB)`,
    ROUND(((index_length) / 1024 / 1024), 2) AS `Index Size (MB)`,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS `Total Size (MB)`
FROM information_schema.TABLES
WHERE table_schema = 'smartfactory_db' AND table_name = 'SensorLogs';

-- 2. LOẠI BỎ "FAT INDEX" KHỔNG LỒ VÀ TẠO LEAN INDEX TINH GỌN
ALTER TABLE SensorLogs DROP INDEX idx_fat_covering;

-- Chỉ index các cột phục vụ điều kiện Lọc (WHERE) và Sắp xếp (ORDER BY)
CREATE INDEX idx_lean_search ON SensorLogs(sensor_id, recorded_at);

-- 3. KIỂM TRA LẠI DUNG LƯỢNG SAU KHI DỌN DẸP
SHOW TABLE STATUS LIKE 'SensorLogs';

-- 4. CHẠY LỆNH EXPLAIN ĐỂ ĐÁNH GIÁ KẾ HOẠCH TRUY VẤN CỦA DASHBOARD
EXPLAIN SELECT temperature, humidity, status 
FROM SensorLogs 
WHERE sensor_id = 105 AND recorded_at >= '2026-06-20 00:00:00';