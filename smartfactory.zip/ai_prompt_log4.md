# NHẬT KÝ TRA CỨU KIẾN TRÚC INDEX VÀ BỘ NHỚ LƯU TRỮ (AI PROMPT LOG)

## Prompt 1: Tìm hiểu khái niệm Covering Index và tác hại đối với Write-Heavy System
* **User Query:** "Trong MySQL InnoDB, Covering Index là gì? Tại sao tạo Covering Index bao phủ toàn bộ các cột trên một bảng có tần suất INSERT cao (như IoT Sensor Logs) lại gây ra hiện tượng Write Penalty và làm phình dung lượng Index_length?"
* **AI Clarification & Learning Output:** 
  * AI giải thích Covering Index giúp truy vấn không cần đọc Clustered Index (Primary Key Table) vì tất cả dữ liệu đã nằm trên leaf nodes của Secondary Index.
  * Tuy nhiên, đối với thao tác `INSERT`, mọi Secondary Index đều phải cập nhật B-Tree. Khi Index chứa nhiều cột lớn, dung lượng 1 trang B-Tree (16KB) chứa được ít record hơn, dẫn tới B-Tree liên tục bị `Page Split`. Việc ghi ngẫu nhiên (Random Disk I/O) để re-balance B-Tree chính là nguyên nhân gây chậm luồng Ghi.

## Prompt 2: So sánh Clustered Index và Secondary Index trong InnoDB
* **User Query:** "Hãy giải thích sự khác biệt về mặt lưu trữ trên đĩa cứng giữa Clustered Index và Secondary Index trong InnoDB MySQL. Điều gì xảy ra khi câu lệnh SELECT không đạt được Covering Index?"
* **AI Clarification & Learning Output:**
  * **Clustered Index:** Chứa toàn bộ dữ liệu thực tế của dòng (Row Data) sắp xếp theo Primary Key.
  * **Secondary Index:** Chỉ chứa các cột được Index + Giá trị của Primary Key (Pointer).
  * Khi câu lệnh `SELECT` không dùng Covering Index (ví dụ chọn cột `temperature` nằm ngoài `idx_lean_search`), MySQL dùng Secondary Index để tìm ra `log_id` (Primary Key), sau đó dùng `log_id` tra cứu ngược lại Clustered Index để lấy các cột còn lại. Thao tác này gọi là **Bookmark Lookup** hoặc **Secondary Key Lookups**.

## Prompt 3: Tính toán Byte Size của các kiểu dữ liệu trong MySQL
* **User Query:** "Hãy tính toán kích thước lưu trữ (Byte level) của các kiểu dữ liệu: BIGINT, INT, DATETIME, DECIMAL(5,2), VARCHAR(20) trong MySQL để minh họa footprint của B-Tree Index."
* **AI Clarification & Learning Output:**
  * `BIGINT`: 8 bytes.
  * `INT`: 4 bytes.
  * `DATETIME`: 5 bytes.
  * `DECIMAL(5,2)`: 3 bytes.
  * `VARCHAR(20)` (utf8mb4): 1 đến 81 bytes (tùy độ dài chuỗi + 1 byte prefix).
  * *Kết luận áp dụng:* Bỏ 3 cột `temperature`, `humidity`, `status` khỏi Index giúp tiết kiệm hơn ~85% không gian lưu trữ cho mỗi nút chỉ mục B-Tree.