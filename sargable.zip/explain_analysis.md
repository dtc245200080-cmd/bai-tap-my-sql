# Phân Tích Báo Cáo Hiệu Năng EXPLAIN - PayFlow System

## 1. Kết quả Đối chiếu

| Chỉ số trong EXPLAIN | Truy vấn Cũ (Legacy Query) | Truy vấn Tối ưu (Optimized Query) |
| :--- | :--- | :--- |
| **type** | `ALL` (Full Table Scan) | `range` / `ref` |
| **possible_keys** | `NULL` | `idx_type_date` |
| **key** | `NULL` | `idx_type_date` |
| **rows (Số dòng quét)** | ~5,000,000 dòng | ~150,000 dòng (chỉ quét các dòng khớp tháng 6) |
| **Extra** | `Using where` | `Using index condition` |

## 2. Kết luận Tóm tắt
TRUY VẤN CỦA KẾ TOÁN BỊ ĐIỂM NGHẼN DO BỌC HÀM `YEAR()` VÀ `MONTH()` LÊN CỘT `created_at` NÊN MYSQL PHẢI QUÉT TOÀN BỘ 5 TRIỆU DÒNG (`type = ALL`).

SAU KHÍ THÊM COMPOSITE INDEX `idx_type_date(transaction_type, created_at)` VÀ CHUYỂN TRUY VẤN SANG DẠNG SARGABLE (`>=` VÀ `<`), MYSQL CHỈ QUÉT ĐÚNG KHOẢNG DỮ LIỆU CẦN TÌM (`type = range`). THỜI GIAN GIẢM TỪ 45 GIÂY XUỐNG DƯỚI 0.1 GIÂY, GIẢI QUYẾT TRIỆT ĐỂ LỖI 100% CPU VÀ TABLE LOCK.