# Nhật Ký Tương Tác AI (Prompt Log)

1. **Prompt 1 (Hiểu nguyên nhân vô hiệu Index):**
   > *"Trong MySQL, nếu tôi tạo Index cho một cột ngày tháng, nhưng trong mệnh đề WHERE tôi lại viết WHERE YEAR(col) = 2026, tại sao MySQL lại từ chối sử dụng Index và phải quét toàn bộ bảng (Full Table Scan)?"*
   - **Ghi nhận:** Hiểu rõ khái niệm SARGable và lý do B-Tree không thể áp dụng Binary Search khi cột bị bọc bởi hàm.

2. **Prompt 2 (Thiết kế Index tối ưu):**
   > *"Khi thiết kế một Composite Index trong MySQL cho cột (transaction_type, created_at), thứ tự các cột trong Index có quan trọng không? Tôi nên đặt cột nào đứng trước để có hiệu suất lọc dữ liệu tốt nhất?"*
   - **Ghi nhận:** Hiểu nguyên tắc Leftmost Prefix và quy tắc ưu tiên đặt cột so sánh chính xác (`=`) lên trước cột so sánh khoảng (`range`).

3. **Prompt 3 (Đánh giá chỉ số EXPLAIN):**
   > *"Trong kết quả EXPLAIN của MySQL, ý nghĩa của các giá trị trong cột type từ xấu nhất đến tốt nhất là gì? Phân biệt 'Using index condition' và 'Using index' trong cột Extra."*
   - **Ghi nhận:** Nắm vững thang đo từ `ALL` -> `index` -> `range` -> `ref` -> `eq_ref` -> `const`.