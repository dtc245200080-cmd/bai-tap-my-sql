-- ========================================================
-- HỆ THỐNG PAYFLOW - TỐI ƯU HÓA TRUY VẤN BÁO CÁO KẾ TOÁN
-- Author: Database Performance Engineer
-- ========================================================

USE payflow_db;

-- 1. Tạo Composite Index để hỗ trợ lọc SARGable
-- Đặt transaction_type (phép so sánh =) trước created_at (phép so sánh Range)
CREATE INDEX idx_type_date ON Transactions(transaction_type, created_at);

-- 2. Truy vấn tối ưu hóa (Thay thế hàm YEAR/MONTH bằng Range Conditions)
EXPLAIN 
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT' 
  AND created_at >= '2026-06-01 00:00:00' 
  AND created_at < '2026-07-01 00:00:00';