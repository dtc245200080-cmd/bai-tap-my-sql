# Giải trình kỹ thuật: COUNT(o.order_id) vs COUNT(*)

Khi thực hiện `LEFT JOIN` giữa bảng `Customers` (bảng trái) và `Orders` (bảng phụ/bên phải), đối với những khách hàng chưa từng mua hàng (như Charlie), toàn bộ các cột trích xuất từ bảng `Orders` sẽ mang giá trị `NULL`.

- **Sử dụng `COUNT(*)`:** Hàm này đếm số lượng dòng được duyệt qua trong nhóm. Dù khách hàng không có đơn hàng nào, dòng `LEFT JOIN` vẫn tạo ra một hàng kết hợp chứa giá trị `NULL`. `COUNT(*)` sẽ đếm dòng chứa `NULL` này và trả về giá trị **1** (Sai thực tế).
- **Sử dụng `COUNT(o.order_id)`:** Hàm `COUNT(column_name)` chỉ đếm các giá trị **khác `NULL`** trong cột chỉ định. Với khách hàng chưa mua hàng, `o.order_id` nhận giá trị `NULL`, do đó hàm bỏ qua và trả về kết quả chuẩn xác là **0**.