# Nhật ký tương tác AI (AI Prompt Log)

### Prompt 1: Tìm hiểu sự khác biệt hàm COUNT trong LEFT JOIN
- **Hỏi:** Trong MySQL, khi dùng LEFT JOIN kết hợp GROUP BY, sự khác biệt giữa COUNT(*) và COUNT(bảng_phụ.id) là gì nếu bản ghi bên bảng phụ mang giá trị NULL?
- **Bài học:** COUNT(*) đếm toàn bộ dòng kết nối (kể cả dòng có NULL), còn COUNT(column) bỏ qua NULL. Cần dùng COUNT(bảng_phụ.id) để đếm chính xác số lượng bản ghi thực tế của bảng bên phải.

### Prompt 2: Phân tích hiệu năng Anti-Join vs Subquery
- **Hỏi:** Phân tích hiệu năng giữa kỹ thuật Anti-Join (LEFT JOIN + IS NULL) và Subquery (NOT IN / NOT EXISTS) trong MySQL khi tìm bản ghi không tồn tại ở bảng liên kết?
- **Bài học:** Kỹ thuật `LEFT JOIN ... WHERE o.id IS NULL` (Anti-Join) hoặc `NOT EXISTS` giúp MySQL Optimizer tận dụng tốt Indexes (tránh Full Table Scan), mang lại hiệu năng cao hơn nhiều so với `NOT IN` (vốn nhạy cảm với giá trị NULL và dễ bị chậm).

### Prompt 3: Cơ chế Join Optimizer
- **Hỏi:** Thuật toán Block Nested-Loop Join (BNL) và Hash Join trong MySQL Optimizer xử lý các câu lệnh JOIN như thế nào?
- **Bài học:** Hiểu cơ chế MySQL tự động lựa chọn bảng bên ngoài (Outer loop) và bảng bên trong (Inner loop) để tối ưu hóa bộ nhớ RAM và số lần đọc đĩa khi thực thi JOIN.