# Nhật Ký Tra Cứu Tối Ưu Hóa Cơ Sở Dữ Liệu Với AI

**Dự án:** QuickFeed  
**Vai trò:** DBA Tra cứu khái niệm & Kỹ thuật nâng cao  

---

## Prompt 1: Tìm hiểu truy vấn dung lượng lưu trữ trong MySQL
* **User:** *"Trong MySQL, làm thế nào để tôi có thể dùng câu lệnh SQL truy vấn bảng `information_schema.TABLES` để xem dung lượng tính bằng Megabyte (MB) của Data và Index trên một bảng cụ thể?"*
* **AI Output Summary:** Giải thích cấu trúc các cột `DATA_LENGTH` và `INDEX_LENGTH` trong bảng `information_schema.TABLES` (đơn vị Bytes). Hướng dẫn công thức chia cho `1024 * 1024` để đổi sang MB và sử dụng hàm `ROUND()` để làm tròn kết quả.

---

## Prompt 2: Khái niệm Cardinality và tác hại trên B-Tree Index
* **User:** *"Hãy giải thích khái niệm Cardinality trong Database. Tại sao việc tạo B-Tree Index trên các cột có Cardinality cực thấp như Boolean (0/1) hoặc Enum ít giá trị lại không giúp tăng tốc câu lệnh SELECT mà còn làm chậm lệnh INSERT?"*
* **AI Output Summary:** 
  * **Cardinality** là số lượng giá trị duy nhất (Unique Values) xuất hiện trong một cột dữ liệu.
  * Với các cột Boolean (50% value 0, 50% value 1), tỷ lệ lọc (Selectivity) rất kém. MySQL Query Optimizer sẽ nhận thấy việc duyệt qua Index B-Tree rồi thực hiện Bookmark Lookup (Random I/O) đắt đỏ hơn nhiều so với việc quét thẳng toàn bộ bảng (**Full Table Scan**).
  * Do Optimizer bỏ qua Index này khi đọc, nhưng vẫn bắt hệ thống phải cập nhật nút B-Tree khi ghi (`INSERT`), dẫn đến Index hoàn toàn vô dụng và làm giảm hiệu năng ghi nghiêm trọng.

---

## Prompt 3: Giải pháp thay thế cho cột văn bản dài (TEXT)
* **User:** *"Nếu muốn tìm kiếm từ khóa bên trong cột content (kiểu TEXT) mà không làm phình dung lượng B-Tree Index và không gây chậm lệnh INSERT như B-Tree Index thường, tôi nên dùng giải pháp nào trong MySQL?"*
* **AI Output Summary:** Gợi ý chuyển hướng sang sử dụng **FULLTEXT Index** (dựa trên cơ chế Inverted Index) thay vì B-Tree Index thông thường. Đồng thời gợi ý việc tách search engine ra các hệ thống chuyên dụng như Elasticsearch/OpenSearch nếu lượng dữ liệu đạt quy mô cực lớn.