# Báo Cáo Tối Ưu Hóa Storage & Performance - Dự Án QuickFeed

**Người thực hiện:** Database Administrator (DBA)  
**Đối tượng:** Tech Lead & Hệ thống QuickFeed  

---

## 1. Phân Tích Đánh Đổi Read vs. Write (Trade-off)
Index trong InnoDB là cấu trúc dữ liệu cây B-Tree giúp tăng tốc truy vấn đọc (`SELECT`). Tuy nhiên, việc duy trì quá nhiều Index dẫn đến chi phí ghi (`INSERT`, `UPDATE`, `DELETE`) vô cùng tốn kém. 

Mỗi khi người dùng đăng status mới, MySQL phải cập nhật Clustered Index cùng **tất cả các Secondary Indexes**. Việc này gây ra hiện tượng phân trang (**Page Split**) và các thao tác Disk I/O ngẫu nhiên liên tục. Đối với `idx_content` (prefix 255 ký tự) và các Index có Cardinality cực thấp (`idx_post_type`, `idx_is_visible`), chi phí bảo trì B-Tree vượt quá lợi ích tìm kiếm, trực tiếp gây ra lỗi **Timeout (5–10 giây)** khi đăng bài.

---

## 2. Bảng So Sánh Thông Số Trước Và Sau Tối Ưu

| Thông số (Bảng Posts) | Trước tối ưu (5 Indexes) | Sau tối ưu (2 Indexes) | Mức độ cải thiện |
| :--- | :--- | :--- | :--- |
| **Data Size (MB)** | 500 MB | 500 MB | Không thay đổi |
| **Index Size (MB)** | 1,050 MB | 120 MB | **Giảm ~88.5%** |
| **Tổng dung lượng** | 1,550 MB | 620 MB | **Tiết kiệm 60% ổ cứng** |
| **Số cây B-Tree cần ghi** | 6 (1 Primary + 5 Secondary) | 3 (1 Primary + 2 Secondary) | **Giảm 50% thao tác I/O** |
| **Thời gian INSERT status** | 5 – 10 giây (Timeout) | < 100 ms | **Thành công tức thì** |

---

## 3. Kết Luận
Việc loại bỏ 3 Index không hiệu quả đã giải cứu hệ thống khỏi nguy cơ tràn đĩa cứng, khôi phục tốc độ đăng bài thực tế và đảm bảo tài nguyên RAM (Buffer Pool) tập trung cho các câu lệnh truy vấn quan trọng (`user_id`, `created_at`).